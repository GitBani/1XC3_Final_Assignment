/**
 * @file course.h
 * @author Bani Somo
 * @brief Header file containing struct and function definitions. Implemented in courses.c 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Struct to represent courses. 
 * struct contains: 
 * - course name 
 * - code
 * - array of students 
 * - number of students
 * @warning Course name cannot exceed 100 characters and course code cannot exceed 50.
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);