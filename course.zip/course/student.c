/**
 * @file student.c
 * @author Bani Somo
 * @brief Defines functions to use on student struct.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief adds a grade into a given student's array of grades.
 * 
 * @param student - Student to add grade to.
 * @param grade - Grade to add to student's grade array.
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // If this grade is their first, allocate space on heap to store it.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    // If array already defined, reallocate more space for the new grade.
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Adds new grade to student's grade array.
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Returns a student's average grade.
 * 
 * @param student - Student whose average is being calculated.
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Loops through grade list and calculates total.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // Returns average grade.
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints student.
 * 
 * @param student - Student to print.
 */
void print_student(Student* student)
{
  // Prints all info stored in student.
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Loops through student's grade array and prints its elements.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Randomly generates a student.
 * 
 * @param grades - number of grades to generate.
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  // Arrays of possible first and last names.
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  // defines array on heap to store new student.
  Student *new_student = calloc(1, sizeof(Student));

  // Copies a random first and last name from the arrays as the student's name.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Gives student random student id.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Generates random grades.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  // returns pointer to student.
  return new_student;
}