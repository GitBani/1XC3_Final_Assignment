/**
 * @file main.c
 * @author Bani Somo
 * @brief Demonstrates how the student and course libraries work.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "course.h"

/**
 * @brief Tests the functions from the libraries to demonstrate how they work.
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));

  // Defines a course.
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // Creates random students and enrolls them into the course.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // Pointer to pointer of the top student and prints his name.
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Prints total number of passing students and their names.
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}