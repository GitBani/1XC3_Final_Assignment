/**
 * @file course.c
 * @author Bani Somo
 * @brief Defines functions to use on course struct.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds a given student into the array of enrolled students of a given course.
 * 
 * @param course - Course that student is enrolling in.
 * @param student - Student who is enrolling in the course.
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // Allocates space on heap if this is the only student.
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // If array of students already definied, reallocate space for new student.
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Add student to the end of array of enrolled students.
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints course.
 * 
 * @param course - Course to print.
 */
void print_course(Course* course)
{ // prints info stored in course.
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // loops through array of enrolled students and prints each name.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns student with the highest average of a given course.
 * 
 * @param course - course to search through.
 * @return Student*
 */
Student* top_student(Course* course)
{ // Do nothing when there are no students in the course.
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  // begin with first student being the highest
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  // loops through array and rewrites highest until the end
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  // returns pointer to Student with highest average
  return student;
}

/**
 * @brief Returns an array of all passing students in a given course and rewrites the value of the number of passing students.
 * 
 * @param course - Course to look through.
 * @param total_passing - Total number of passing students.
 * @return Student*
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  // calculates number of passing students.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  // allocates enough space on heap for number of passing students.
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // loops through array of students again, if they are passing then adds them to the array.
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  // indirectly overwrites value of total_passing.
  *total_passing = count;
  //returns the array of passing students.
  return passing;
}