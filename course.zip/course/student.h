/**
 * @file student.h
 * @author Bani Somo
 * @brief Header file containing struct and function definitions. Implemented in students.c
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief struct for representing a student. 
 * struct contains:
 * - first name of student
 * - last name of student 
 * - student id
 * - array of grades
 * - number of grades
 * @warning First and last names cannot exceed 50 characters
 * @warning Student id must be 11 characters 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
